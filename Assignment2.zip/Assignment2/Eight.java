import java.util.Scanner;

public class Eight {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        System.out.print("Enter marks for C: ");
        double marksC = scanner.nextDouble();
        System.out.print("Enter marks for C++: ");
        double marksCpp = scanner.nextDouble();
        System.out.print("Enter marks for Java: ");
        double marksJava = scanner.nextDouble();
        System.out.print("Enter marks for Python: ");
        double marksPython = scanner.nextDouble();

        int credit = 3;

        
        char gradeC = calculateGrade(marksC);
        char gradeCpp = calculateGrade(marksCpp);
        char gradeJava = calculateGrade(marksJava);
        char gradePython = calculateGrade(marksPython);

        double totalMarks = marksC + marksCpp + marksJava + marksPython;
        double percentage = (totalMarks / (4 * 100)) * 100;

        double sgpa = calculateSGPA(gradeC, gradeCpp, gradeJava, gradePython);

        System.out.println("Grades:");
        System.out.println("C: " + gradeC);
        System.out.println("C++: " + gradeCpp);
        System.out.println("Java: " + gradeJava);
        System.out.println("Python: " + gradePython);

        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Percentage: " + percentage + "%");
        
        System.out.println("SGPA: " + sgpa);

        scanner.close();
    }

    
    public static char calculateGrade(double marks) {
        if (marks >= 90) {
            return 'A';
        } else if (marks >= 80) {
            return 'B';
        } else if (marks >= 70) {
            return 'C';
        } else if (marks >= 60) {
            return 'D';
        } else {
            return 'F';
        }
    }


    public static double calculateSGPA(char gradeC, char gradeCpp, char gradeJava, char gradePython) {
        int totalCredits = 4 * 3;
        int totalGradePoints = getGradePoint(gradeC) + getGradePoint(gradeCpp) + getGradePoint(gradeJava) + getGradePoint(gradePython);
        double sgpa = (double) totalGradePoints / totalCredits;
        return sgpa;
    }

   
    public static int getGradePoint(char grade) {
        switch (grade) {
            case 'A':
                return 10;
            case 'B':
                return 8;
            case 'C':
                return 6;
            case 'D':
                return 4;
            case 'F':
                return 0;
            default:
                return 0;
        }
    }
}
